package model;

public interface PSE {
	
	//all methods declared are implicitly defined as
	//public abstract
	void displayFinancialStatement();
	void displayTotalMarketShares();
}
