package model;

public interface PSERequirement extends PSE {

	//all variables declared are implicitly defined
		//as public static final
	String MIN_LARGE_CAPITALIZATION 
		= "Php 2,000,000,000.00";
	
	String MIN_SHARES_SOLD = "5,000,000";
}
